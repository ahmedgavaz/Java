package Generic_Box;

import java.util.ArrayList;
import java.util.List;

public class Box<T> {
    private List<T> box;

    public Box(){
        this.box=new ArrayList<>();
    }

    public void add(T element){
        this.box.add(element);
    }
    @Override
    public String toString(){
        StringBuilder text = new StringBuilder();
        for (T elem:box) {
            text.append(elem.getClass().getName() + ": " + elem + "\n");
        }
        return text.toString();
    }
}
