package Generic_Box;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        /* Задача 1
        Scanner scanner = new Scanner(System.in);
        Box<String> list = new Box<>();
        int n =Integer.parseInt(scanner.nextLine());
        for (int i = 0; i <n; i++) {
            list.add(scanner.nextLine());
        }
        System.out.println(list);*/

        Scanner scanner = new Scanner(System.in);
        Box<Integer> list = new Box<>();
        int n =Integer.parseInt(scanner.nextLine());
        for (int i = 0; i <n; i++) {
            list.add(Integer.parseInt(scanner.nextLine()));
        }
        System.out.println(list);
    }
}
