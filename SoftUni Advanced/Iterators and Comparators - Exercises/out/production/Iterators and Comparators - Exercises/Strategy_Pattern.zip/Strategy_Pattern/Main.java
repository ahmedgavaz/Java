package Strategy_Pattern;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Person> list1 = new ArrayList<>();
        List<Person> list2 = new ArrayList<>();
        int n =Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String[] command = scanner.nextLine().split("\\s+");
            Person person = new Person(command[0],Integer.parseInt(command[1]));
            list1.add(person);
            list2.add(person);
        }
        Comparator<Person> comparator1 = new First();
        Collections.sort(list1,comparator1);
        Comparator<Person> comparator2 = new Second();
        Collections.sort(list2,comparator2);
        for (Person elem:list1) {
            System.out.println(elem.getName()+" "+elem.getAge());
        }
        for (Person elem:list2) {
            System.out.println(elem.getName()+" "+elem.getAge());
        }
    }
}
