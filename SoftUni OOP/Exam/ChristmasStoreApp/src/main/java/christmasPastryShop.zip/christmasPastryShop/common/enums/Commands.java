package christmasPastryShop.common.enums;

public enum Commands {
    AddDelicacy,
    AddCocktail,
    AddBooth,
    ReserveBooth,
    OrderDelicacy,
    OrderCocktail,
    LeaveBooth,
    GetIncome,
    END
}
